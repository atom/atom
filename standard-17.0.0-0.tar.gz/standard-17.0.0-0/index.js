/*! standard. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
import { StandardEngine } from 'standard-engine'
import options from './options.js'

export default new StandardEngine(options)
